// Функция для установки темы
function setTheme(theme) {
  document.body.dataset.theme = theme;
  localStorage.setItem('theme', theme); // Сохраняем тему в localStorage
}

// Функция для получения сохранённой темы из localStorage
function getSavedTheme() {
  return localStorage.getItem('theme') || 'white'; // Возвращаем сохранённую тему или дефолтную
}

// При загрузке страницы устанавливаем сохранённую тему
document.addEventListener('DOMContentLoaded', () => {
  let savedTheme = getSavedTheme();
  setTheme(savedTheme);

  // Устанавливаем активный класс для кнопки, соответствующей сохранённой теме
  let activeButton = document.querySelector(`button[data-theme="${savedTheme}"]`);
  if (activeButton) activeButton.classList.add('is_active');
});



// Обработчик для текста с анимацией hover
document.querySelectorAll('.text_roll').forEach(link => {
  let span = link.querySelector('span');
  span.dataset.hover = span.textContent;
});






// header var
let header = document.querySelector('.u-header');
let header_height = header.getBoundingClientRect().height
document.documentElement.style.setProperty('--headerHeight', `${header_height}px`)

if (window.matchMedia('(min-width: 641px)').matches)  {
  function throttle(func, limit) {
    let inThrottle;
    return function() {
      const args = arguments;
      const context = this;
      if (!inThrottle) {
        func.apply(context, args);
        inThrottle = true;
        setTimeout(() => inThrottle = false, limit);
      }
    };
  }

  document.addEventListener('scroll', throttle(function() {
    const firstBlock = document.querySelector('main > div:first-child');
    const firstBlockRect = firstBlock.getBoundingClientRect();

    if (firstBlockRect.top < window.innerHeight && firstBlockRect.bottom >= 0) {
      header.classList.remove('is_scroll');
    } else {
      header.classList.add('is_scroll');
    }
  }, 100));

} else{
  let btn_open_menu = document.querySelector('.u-header__button-open-menu');

  btn_open_menu.addEventListener('click', () => {
    // header_menu.classList.toggle('opening_menu'); // Переключаем класс для .u-header
    document.querySelector('html').classList.toggle('opening-menu')
  });

  window.addEventListener('scroll', function() {
    // Получаем текущую позицию прокрутки
    const scrollPosition = window.scrollY || window.pageYOffset;

    // Проверяем, прокручена ли страница больше, чем высота хедера
    if (scrollPosition > header_height) {
      // Добавляем класс is_scroll
      header.classList.add('is_scroll');
    } else {
      // Убираем класс is_scroll
      header.classList.remove('is_scroll');
    }
  });

}

function footerSticky(){
  let footer = document.querySelector('.footer')
  if(footer){
    let footer_height = footer.offsetHeight
    document.documentElement.style.setProperty('--footerHeight', `${footer_height}px`)
    console.log(footer_height)
  }
}


document.addEventListener("DOMContentLoaded", (event) => {
  footerSticky()

});





function preloaderStart(){
  let preloader = document.querySelector('.preloader'),
preloader__logo = preloader.querySelector('.preloader__logo')
gsap.to(preloader__logo, {
  scale: 1.3,
  opacity: 1,
  filter: "blur(0px)",
  duration: 2,
  onComplete: () => {

    function preloaderAfterLoad(){
      gsap.to(preloader, {  transform: 'scaleY(0)',}, );
    }
    function checkPageLoad() {
      if (document.readyState === 'complete' || document.readyState === 'interactive') {
        preloaderAfterLoad()
        clearInterval(intervalId);
      }
    }
    const intervalId = setInterval(checkPageLoad, 500);
  }
});
setTimeout(() => {
  window.scroll({ top: -1, left: 0, behavior: "smooth" });
}, 300);
}
preloaderStart()

function modalImage(section) {
  const modal = document.getElementById('fullscreen-modal');
  const modalContainer = modal.querySelector('.fullscreen-modal_container');
  const modalPicture = modalContainer.querySelector('picture');

  const modalImg = document.createElement('img');
  const modalSources = modalPicture.querySelectorAll('source');

  const closeBtn = modal.querySelector('.close');

  section.querySelectorAll('.card__image').forEach(imgContainer => {
    const btn = document.createElement('div');
    btn.classList.add('btn-full-img');
    btn.textContent = 'click to open';
    imgContainer.append(btn);

    btn.addEventListener('click', () => {
      // Получаем изображение и source из карточки
      const cardImg = imgContainer.querySelector('img');
      const cardSources = imgContainer.querySelectorAll('source');

      // Очищаем существующие source в модальном окне
      modalPicture.innerHTML = '';


      // Добавляем только source с разрешением 1640
      cardSources.forEach(cardSource => {
        if (cardSource.srcset.includes('1640')) {
          const newSource = document.createElement('source');
          newSource.srcset = cardSource.srcset;
          newSource.type = cardSource.type;
          newSource.media = cardSource.media;
          modalPicture.appendChild(newSource);
        }
      });
      modalPicture.append(modalImg)
      // Устанавливаем изображение для модального окна
      modalImg.src = cardImg.src.replace('960', '1640'); // Заменяем 960 на 1640 в src
      console.log(cardImg.src.replace('960', '1640'))
      // Открываем модальное окно
      modal.classList.add('is_active');
    });
  });


// Закрываем модальное окно при клике на крестик
  closeBtn.addEventListener('click', () => {
    modal.classList.remove('is_active');
    modalPicture.innerHTML = ''
  });
// Закрываем модальное окно при клике вне изображения
  modal.addEventListener('click', (e) => {
    if (e.target !== modalContainer.querySelector('img')) {
      modal.classList.remove('is_active');
      modalPicture.innerHTML = '';
    }
  });
}


if (window.matchMedia('(min-width: 641px)').matches)  {
  function scrollbarHero(){
    let progressBar = document.querySelector('.scrollbar__progress');
    let progressValue = document.querySelector('.scrollbar__value');
    let heroBlock = document.querySelector('.u-hero'); // Находим блок u-hero
    let heroHeight = heroBlock.offsetHeight; // Высота блока u-hero

    window.addEventListener('scroll', function () {
      let scrollTop = window.scrollY || window.pageYOffset; // Текущая прокрутка

      // Вычисляем прогресс: насколько блок "прокрутился" вниз
      let progress = (scrollTop / heroHeight) * 100;

      // Ограничиваем прогресс в пределах от 0 до 100
      progress = Math.max(0, Math.min(100, progress));

      // Обратная механика: вычитаем процент прокрутки из 100
      let reverseProgress = 100 - progress;
      progressBar.style.height = reverseProgress + '%'; // Устанавливаем высоту прогресс-бара
      progressValue.textContent = Math.round(reverseProgress) + '%'; // Устанавливаем текст процентов
    });
  }

}

let next_work = document.querySelector('.next-work__container');
if(next_work && window.matchMedia('(min-width: 641px)').matches){
    let progress_link = next_work
    let progress = 0;
    let interval;

    function updateProgress(step) {
      if (interval) {
        clearInterval(interval);
      }

      interval = setInterval(() => {
        progress += step;
        progress_link.style.setProperty('--progressValue', `${progress}%`);

        if ((step > 0 && progress >= 100) || (step < 0 && progress <= 0)) {
          clearInterval(interval);
          interval = null;
          if (step > 0) {
            window.location.href = progress_link.href;
          }
        }
      }, 30);
    }

    progress_link.addEventListener('mouseenter', () => updateProgress(1));
    progress_link.addEventListener('mouseleave', () => updateProgress(-1));

}


if (window.matchMedia('(min-width: 641px)').matches) {
// Получаем элементы
  const hero = document.querySelector('.u-hero__container');

// Создаем анимацию с помощью GSAP и ScrollTrigger
  gsap.to(hero, {
    scrollTrigger: {
      trigger: hero,
      start: 'bottom bottom', // Начинаем анимацию, когда верхний край .u-hero достигает верха окна просмотра
      end: 'bottom end: `+=${window.innerHeight}`,', // Заканчиваем анимацию, когда нижний край .u-hero достигает нижнего края окна просмотра
      scrub: true, // Анимация будет плавно изменяться при прокрутке
      pin: true, // Фиксируем .u-hero на месте
      pinSpacing: false, // Не добавляем отступы вокруг фиксированного блока
      markers: false,
    }
  });


}

let activateImageTextSliderMob = (swiper_item) => {
  // Находим слайдер
  let slider = swiper_item.querySelector('.u-image-text__image');

  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');

  // Создаем кнопки навигации
  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper--prev');
  slider_controls.append(swiper_nav_prev);

  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper--next');
  slider_controls.append(swiper_nav_next);

  swiper_item.querySelectorAll('.card img').forEach(img => {
    img.classList.add('swiper-gl-image');
  });
  // Инициализация Swiper
  const projectSliderMob = new Swiper(slider, {
    modules: [SwiperGL],
    effect: 'gl',
    // SwiperGL module parameters
    gl: {
      // specify required shader effect
      shader: 'morph-x',
    },
    createElements: true,
    slideClass: 'card',
    grabCursor: true,
    simulateTouch: true,
    freeMode: false,
    allowTouchMove: true,
    uniqueNavElements: true,
    loop: true,
    slidesPerView: 1,
    spaceBetween: 8,
    mousewheel: {
      forceToAxis: true,
    },
    navigation: {
      nextEl: swiper_nav_next,
      prevEl: swiper_nav_prev,
    },
  });

  // Добавляем прогресс-бар
  if (swiper_item && swiper_item.closest('.u-image-text')) {
    swiper_item.querySelector('.u-image-text__note').append(slider_controls);
  }
  // Массив с текстами для каждого слайда
  const slideTexts = [
    "Disposable in the Vasileostrovskaya metro station in Saint Petersburg",
    "He is a firm believer in the need to give contemporary photography a new look and pursues his goals day after day.",
    "Results and exhibitions"
  ];
  // Находим элемент для отображения текста
  const noteTextElement = swiper_item.querySelector('.u-image-text__note div p');

  // Обновляем текст при изменении слайда
  projectSliderMob.on('slideChange', function () {
    const activeIndex = projectSliderMob.realIndex; // Получаем индекс активного слайда
    noteTextElement.textContent = slideTexts[activeIndex]; // Обновляем текст
  });

  // Инициализация текста для первого слайда
  noteTextElement.textContent = slideTexts[0];

};
let u_image_text= document.querySelectorAll('.u-image-text');
u_image_text.forEach(section => {
  if (window.matchMedia('(max-width: 640px)').matches) {
    activateImageTextSliderMob(section)

  }

})

let activateProcessSlider = (swiper_item) => {
  // Находим слайдер
  let slider = swiper_item.querySelector('.u-process-slider__list');

  // Создаем элементы для пагинации и прогресс-бара
  let slider_pagination = document.createElement('div');
  slider_pagination.classList.add('slider--pagination');

  let slider_progressbar = document.createElement('div');
  slider_progressbar.classList.add('slider--progressbar');

  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');

  slider_controls.append(slider_progressbar);

  // Создаем кнопки навигации
  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper--prev');
  slider_controls.append(swiper_nav_prev);

  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper--next');
  slider_controls.append(swiper_nav_next);

  // Инициализация Swiper
  if (window.matchMedia('(min-width: 641px)').matches) {
    const processSliderDesk = new Swiper(slider, {
      createElements: true,
      slideClass: 'card',
      slidesPerView: 1,
      loop: true,
      spaceBetween: 32,
      initialSlide: 1,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      pagination: {
        el: slider_progressbar,
        type: "progressbar",
      },
      breakpoints: {
        640: {
          slidesPerView: 2.5,
          spaceBetween: 8
        }
      },
      on: {
        init: function () {
          updatePagination(this); // Обновление пагинации
        },
        slideChange: function () {

          updatePagination(this); // Обновление пагинации
        },
      },
    })
  } else{
    swiper_item.querySelectorAll('.card .card__image img').forEach(img => {
      img.classList.add('swiper-gl-image');
    });
    const processSliderMob = new Swiper(slider, {
      modules: [SwiperGL],
      effect: 'gl',
      // SwiperGL module parameters
      gl: {
        // specify required shader effect
        shader: 'morph-x',
      },
      createElements: true,
      slideClass: 'card',
      slidesPerView: 1,
      loop: true,
      spaceBetween: 32,
      initialSlide: 1,
      mousewheel: {
        forceToAxis: true,
      },
      navigation: {
        nextEl: swiper_nav_next,
        prevEl: swiper_nav_prev,
      },
      pagination: {
        el: slider_progressbar,
        type: "progressbar",
      },
      breakpoints: {
        640: {
          slidesPerView: 2.5,
          spaceBetween: 8
        }
      },
      on: {
        init: function () {
          updatePagination(this); // Обновление пагинации
        },
        slideChange: function () {

          updatePagination(this); // Обновление пагинации
        },
      },
    })
  }

  // Инициализация Swiper

  // Функция для обновления пагинации
  function updatePagination(swiper) {
    const currentSlide = swiper.realIndex + 1; // Текущий слайд (начинаем с 1)
    const totalSlides = swiper.slides.length; // Общее количество слайдов
    slider_pagination.textContent = `${currentSlide} OFF ${totalSlides}`;
  }
  slider_progressbar.append(slider_pagination);
  swiper_item.querySelector('.container').append(slider_controls);

};

let u_process_slider= document.querySelectorAll('.u-process-slider');
u_process_slider.forEach(section => {
  activateProcessSlider(section)
})


let activateHeroSliderMob = (swiper_item) => {
  swiper_item.querySelectorAll('.u-hero__card .card__image img').forEach(img => {
    img.classList.add('swiper-gl-image');
  });
  // Находим слайдер
  let slider = swiper_item.querySelector('.u-hero__list');
  let slider_progressbar = document.createElement('div');
  slider_progressbar.classList.add('u-hero-slider--progressbar');


  // Инициализация Swiper
  const HeroSliderMob = new Swiper(slider, {
    modules: [SwiperGL],
    effect: 'gl',
    // SwiperGL module parameters
    gl: {
      // specify required shader effect
      shader: 'morph-x',
    },
    createElements: true,
    slideClass: 'card',
    grabCursor: true,
    simulateTouch: true,
    freeMode: false,
    allowTouchMove: true,
    uniqueNavElements: true,
    loop: true,
    slidesPerView: 1,
    spaceBetween: 8,
    mousewheel: {
      forceToAxis: true,
    },
    pagination: {
      el: slider_progressbar,
      type: "progressbar",
    },
  });

  // Добавляем прогресс-бар
  if (swiper_item && swiper_item.closest('.u-hero')) {
    swiper_item.prepend(slider_progressbar);
  }

};

// Функция для инициализации анимаций
function initAnimations() {
  let cards = document.querySelectorAll(".u-hero__card:nth-child(n+3)");
  let title = document.querySelector(".u-hero__title"); // Находим элемент с заголовком
  let heroBlock = document.querySelector(".u-hero"); // Находим блок .u-hero

  // Анимация для карточек
  cards.forEach((card, index) => {
    // Разная скорость для каждой карточки
    let speed = 0.3 + Math.random() * 1; // Случайная скорость от 0.5 до 1.5
    gsap.fromTo(card, {
      scale: 0.7,
      y: -300,
    }, {
      y: 0,
      scale: 1,
      duration: speed, // Случайная скорость
      scrollTrigger: {
        trigger: card,
        start: "top 80%", // Анимация начинается, когда карточка на 80% в видимой области
        end: "80% 60%", // Анимация заканчивается, когда карточка на 20% в видимой области
        toggleActions: "play none reverse none",
        scrub: true, // Плавное следование за прокруткой в обе стороны
        markers: false, // Включите маркеры для отладки
        onStart: () => {
          document.querySelector('.pin-spacer').style.zIndex = 3;
        }
      },
    });
  });

  // Анимация для заголовка, привязанная к скроллу блока .u-hero
  gsap.fromTo(title, {
    scale: 2,
    x: '-50%',
    opacity: '15%',
  }, {
    scale: 1,
    x: '0%',
    opacity: '100%',
    scrollTrigger: {
      trigger: heroBlock, // Привязываем анимацию к блоку .u-hero
      start: "top top", // Анимация начинается, когда верхняя граница .u-hero вверху экрана
      end: "bottom top", // Анимация заканчивается, когда нижняя граница .u-hero вверху экрана
      scrub: true, // Плавное следование за прокруткой в обе стороны
      markers: false, // Включите маркеры для отладки
    },
  });
}
function switchTheme(){
// Обработчик для кнопок переключения темы комп
  if (window.matchMedia('(min-width: 641px)').matches) {
    document.querySelectorAll('button[data-theme]').forEach(btn => {
      btn.addEventListener('click', e => {
        let selectedTheme = e.currentTarget.dataset.theme;
        setTheme(selectedTheme); // Устанавливаем выбранную тему

        // Убираем активный класс у всех кнопок и добавляем его к текущей
        document.querySelectorAll('button[data-theme]').forEach(t => {
          t.classList.toggle('is_active', t === e.currentTarget);
        });
      });
    });
  } else{
    // Обработчик для кнопок переключения темы моб

    // Функция для получения следующей темы
    function getNextTheme(currentTheme) {
      let themes = ['white', 'dark', 'color'];
      let currentIndex = themes.indexOf(currentTheme);
      let nextIndex = (currentIndex + 1) % themes.length; // Переход к следующей теме по кругу
      return themes[nextIndex];
    }
    // Обработчик клика на кнопку
    document.querySelector('.u-hero__btn-theme').addEventListener('click', function() {
      let currentTheme = document.body.dataset.theme;
      let nextTheme = getNextTheme(currentTheme);
      setTheme(nextTheme); // Устанавливаем следующую тему
    });
  }
}





let u_hero= document.querySelectorAll('.u-hero');

u_hero.forEach(section => {
  switchTheme()
  if (window.matchMedia('(max-width: 640px)').matches) {
    activateHeroSliderMob(section)
      let heroList = document.querySelector('.u-hero__list');
      function stopAnimation() {
        // Завершаем анимацию после текущего цикла
        heroList.style.animationIterationCount = '1';
        heroList.style.animationFillMode = 'forwards'; // Останавливаем анимацию на последнем кадре
        heroList.removeEventListener('pointerdown', stopAnimation); // Удаляем слушатель события
      }
      heroList.addEventListener('pointerdown', stopAnimation);

  } else {
    GradientsBack()
    modalImage(section)
    // Обработчик для кнопок переключения сетки
    document.querySelectorAll('button[data-grid]').forEach(btn => {
      btn.addEventListener('click', e => {
        let gridState = e.currentTarget.dataset.grid === 'ON' ? 'OFF' : 'ON';
        e.currentTarget.dataset.grid = gridState;
        section.dataset.grid = gridState;
      });
    });
    initAnimations();
    document.addEventListener('DOMContentLoaded', function () {
      scrollbarHero()
    });
  }


})

let activateProjectSliderDesk = (swiper_item) => {


  // Находим слайдер
  let slider = swiper_item.querySelector('.u-project-slider__list');

  // Создаем элементы для пагинации и прогресс-бара
  let slider_pagination = document.createElement('div');
  slider_pagination.classList.add('slider--pagination');
  let slider_progressbar = document.createElement('div');
  slider_progressbar.classList.add('slider--progressbar');
  let slider_controls = document.createElement('div');
  slider_controls.classList.add('slider_controls');
  slider_controls.append(slider_progressbar);

  // Создаем кнопки навигации
  let swiper_nav_prev = document.createElement('div');
  swiper_nav_prev.classList.add('swiper--prev');
  slider_controls.append(swiper_nav_prev);
  let swiper_nav_next = document.createElement('div');
  swiper_nav_next.classList.add('swiper--next');
  slider_controls.append(swiper_nav_next);

  // Проверяем ширину экрана
  const isMobile = window.matchMedia('(max-width: 640px)').matches;

  // Инициализация thumbs слайдера только для десктопов
  let thumbs = null;
  if (!isMobile) {
    // Создаем контейнер для thumbs
    let thumbsContainer = document.createElement('div');
    thumbsContainer.classList.add('u-project-slider__list-thumbs');
    let thumbsWrapper = document.createElement('div');
    thumbsWrapper.classList.add('swiper-wrapper');
    thumbsContainer.appendChild(thumbsWrapper);

    // Копируем слайды для thumbs
    let slides = slider.querySelectorAll('.card');
    slides.forEach((slide, index) => {
      let thumbSlide = document.createElement('div');
      thumbSlide.classList.add('swiper-slide');
      let thumbImage = slide.querySelector('.card__image img').cloneNode(true);
      thumbSlide.appendChild(thumbImage);
      thumbsWrapper.appendChild(thumbSlide);
    });

    // Добавляем thumbs контейнер в swiper_item.querySelector('.container')
    swiper_item.querySelector('.container').appendChild(thumbsContainer);

    // Инициализация thumbs слайдера
    thumbs = new Swiper(thumbsContainer, {
      spaceBetween: 24,
      slidesPerView: 3.5,
      freeMode: true,
      watchSlidesProgress: true,
      watchSlidesVisibility: true,
      speed: 1000,

    });
  }
  swiper_item.querySelectorAll('.card .card__image img').forEach(img => {
    img.classList.add('swiper-gl-image');
  });
  // Инициализация основного слайдера
  const projectSliderDesk = new Swiper(slider, {
    modules: [SwiperGL],
    effect: 'gl',
    // SwiperGL module parameters
    gl: {
      // specify required shader effect
      shader: 'morph-x',
    },
    createElements: true,
    slideClass: 'card',
    grabCursor: true,
    draggable: true,
    simulateTouch: true,
    freeMode: false,
    loop: true,
    slidesPerView: 1,
    loopAdditionalSlides: 10,
    loopPreventsSliding: false,
    spaceBetween: 8, // Отключаем стандартные отступы
    speed: 660,
    mousewheel: {
      forceToAxis: true,
    },
    navigation: {
      nextEl: swiper_nav_next,
      prevEl: swiper_nav_prev,
    },
    pagination: {
      el: slider_progressbar,
      type: "progressbar",
    },
    thumbs: isMobile ? null : { // Подключаем thumbs только для десктопов
      swiper: thumbs,
    },
    on: {
      init: function () {
        updatePagination(this); // Обновление пагинации
      },
      slideChange: function () {
        updatePagination(this); // Обновление пагинации
      },
    },
  });

  // Функция для обновления пагинации
  function updatePagination(swiper) {
    const currentSlide = swiper.realIndex + 1; // Текущий слайд (начинаем с 1)
    const totalSlides = swiper.slides.length; // Общее количество слайдов
    slider_pagination.textContent = `${currentSlide} OFF ${totalSlides}`;
  }

  slider_progressbar.append(slider_pagination);
  swiper_item.querySelector('.container').append(slider_controls);
};

// Инициализация всех слайдеров на странице
let u_project_slider = document.querySelectorAll('.u-project-slider');
u_project_slider.forEach(section => {
  activateProjectSliderDesk(section);
});
